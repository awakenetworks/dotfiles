from .core import Cider

__author__ = "Michael Sanders"
__version__ = "1.1.7"
__all__ = ["Cider"]
